clear all
close all

% inputs
example = 0; % Morelli textbook example multisine Figure 8.21

pwm_elv_fit = [0.0445 -65.185]; % polyfit between pwm(x) and elevator-deg (y)
pwm_ail_fit = [0.0628 -94.205];
pwm_rdr_fit = [0.0653 -98.142];

long_flag = 0;
lat_flag = 1;

if long_flag
    mag = [4];
    effectors = {'elev'};
    file_name = 'multisine_long'; % name of output file
    bins_per_input = 17; % number of harmonic freqeuncy bins per input 
    freq_desired = 2.5; % hertz upper frequency of interest for maneuver 
elseif lat_flag
    mag = [1 1]*6;
    effectors = {'ail', 'rdr'};
    file_name = 'multisine_lat'; % name of output file
    bins_per_input = 10; % number of harmonic freqeuncy bins per input 
    freq_desired = 2.5; % hertz upper frequency of interest for maneuver 
end

for i = 1:length(effectors)
    amp.(effectors{i}) = mag(i);
    power_spec.(effectors{i}) = 'uniform';
end

% specify control power spectrum for inputs
% power_spec.rud = [.1, .15, .2,  .2, .15, .1, .1]; % power spectrum density of rudder
% power_spec.elv = [.1, .15, .2,  .2, .15, .1, .1];
% power_spec.ail = 'uniform';

%% End of Input -----------------------------------------------------------
% function to convert degree to pwm
deg2pwm_elv = getPolynomialInverse(pwm_elv_fit); 
deg2pwm_ail = getPolynomialInverse(pwm_ail_fit); 
deg2pwm_rdr = getPolynomialInverse(pwm_rdr_fit); 

if example % changes the inputs for the example
    for i=1
        amp = struct();
        power_spec = struct();
        bins_per_input = 7; % number of harmonic freqeuncy bins per input 
        freq_desired = 2.2; % hertz upper frequency of interest for maneuver 

        % amplitude of control inputs in degrees
        amp.rud = 2;
        amp.elv = 2;
        amp.ail = 1; 

        % specify control power spectrum for inputs
        power_spec.rud = [.1, .15, .2,  .2, .15, .1, .1]; % power spectrum density of rudder
        power_spec.elv = [.1, .15, .2,  .2, .15, .1, .1];
        power_spec.ail = 'uniform';
        
        phi.rud = [2.8435 2.5259 2.7562 -.5132 -.7433 2.3959 -.7581];
        phi.elv = [2.9478 .6008 -2.6991 -1.6517 2.6902 2.0873 -2.8619];
        phi.ail = [1.5438 -1.6413 1.2011 1.0767 -2.3373 -2.3327 -2.7602];
    end
end

tags = fieldnames(amp); 
n_inputs = length(tags);

m = n_inputs*bins_per_input + 1; % ignore the first bin so that zero is ignored 
t = m/(freq_desired);
num_data_points = 25*freq_desired*t;
% t = 10;

% name of file 
integer_part = floor(freq_desired); % Get the integer part
decimal_part = abs(freq_desired - integer_part); % Get the decimal part
freq_string = sprintf('%d_%d', integer_part, round(decimal_part * 10)); % Scale decimal part for clarity
file_name = sprintf([file_name '_%d_deg' '_' freq_string '_Hz_%d_bins_%d_s.csv'], mag(1), bins_per_input, round(t));

disp(['Maneuver Time ' num2str(t) 's'])
[k_id, ak] = k_and_ak_calc(amp, power_spec, m, tags, n_inputs, bins_per_input);

rpf_threshold = 1.1;
max_iterations = 10;

% Multisine Creation Using Minimization algorithms on Phi
if ~example
    tags = fieldnames(ak);
    for j = 1:length(tags)
       tag = tags{j};
       k_j = k_id.(tag);
       
       % Define the objective function (RPF)
       obj_fun = @(phi) rpf(phi, ak.(tag), k_id.(tag), t);
       
       %initial guess of phase angles
       a = -pi;
       b = pi;
       phi.(tag) = (b - a) .* rand(length(k_j), 1) + a;
       rpf0 = obj_fun(phi.(tag));
       iteration = 0;
       while obj_fun(phi.(tag)) > rpf_threshold && iteration < max_iterations
           a = -pi;
           b = pi;
           phi_c = (b - a) .* rand(length(k_j), 1) + a;
           % Minimize the RPF using the constrained optimization method (fmincon)
           options = optimoptions('fmincon', 'Display', 'iter', 'Algorithm', 'sqp');
           lb = -2*pi*ones(length(k_j), 1); % lower bound
           ub =  2*pi*ones(length(k_j), 1); % upper bound
           [optimal_phi, optimal_rpf] = fmincon(obj_fun, phi_c, [], [],[],[], lb, ub, [], options);
           
           N = num_data_points;
           time = (0:t/N:t)';
           u = zeros(length(time), 1);
           for i = 1:length(ak.(tag))
               u = u + ak.(tag)(i)*sin((2*pi*k_j(i)*time)/t + optimal_phi(i));
           end
           
           indices = find(abs(u) < .05); % array of values that are close to zero mag
           t_init = time(indices(1)); % defines a good initial guess for tau that is close to zero magnitude         
           % shifting inputs to start from zero amplitude
           time_offset_fun = @(tau) time_offset_zeros(tau, ak.(tag), k_j, optimal_phi, t);
           optimal_tau = fminsearch(time_offset_fun, t_init); % initial guess lower bound of 0 upper bound of total time
           d_phi = zeros(length(optimal_phi), 1);
           
           for k = 1:length(k_j)
               d_phi(k) = (2*pi*k_j(k))/t * optimal_tau;
           end
           
           phi_shift = optimal_phi + d_phi;
           rpf_shift = obj_fun(phi_shift);
           if rpf0 > rpf_shift
               phi.(tag) = phi_shift;
               rpf0 = rpf_shift;
           end
           iteration = iteration + 1;
       end   
    end
    
    % Dispaly Results
    disp('Minimized Relative Peak Factor (RPF) for each input:')
    rpf_values = struct();
    tags = fieldnames(phi);
    for j = 1:length(tags)
       tag = tags{j};
       rpf_values.(tag) = rpf(phi.(tag), ak.(tag), k_id.(tag), t);
    end
    disp(rpf_values)
end

disp(['Maneuver Time ' num2str(t) 's'])

[u, time] = multisine_create(ak, amp, k_id, phi, t, num_data_points); 
if long_flag
    u_pwm = round(deg2pwm_elv(u)); % converting to pwm from polynomial relation
elseif lat_flag
    ail = round(deg2pwm_ail(u(:, 1)));
    rdr = round(deg2pwm_rdr(u(:, 2)));
    u_pwm = [ail rdr];
end
u_pwm = u_pwm - u_pwm(1); % subtract initial pwm so everything is a delta
time = round(time*1000); % converting time to ms due to Lua script constraints
% Code that adds a buffer of time at the beginning and end of the inputs

% buffer = .3; % buffer time at start
% time_insert = time(2):mean(diff(time)):buffer;
% new_time = time(2:end) + buffer;
% time_fin = vertcat(time(1), time_insert', new_time);
% 
% trim_inputs = zeros(length(time_insert), width(u_pwm));
% trim_inputs = repmat(u_pwm(1, :), size(trim_inputs, 1), 1);
% 
% inputs_fin = [u_pwm(1,:); trim_inputs; u_pwm(2:end,:)];
% input = [time_fin inputs_fin];

input = [time u_pwm];

T = array2table(input);
T.Properties.VariableNames = ['Time', effectors];
writetable(T, file_name)

function [u, time] = multisine_create(ak, a, k_id, phi, t, num_data_points)
    n_points = num_data_points;
    dt = t/n_points;
    % indices 
    time = (0:dt:t)';
    u = zeros(length(time), length(fieldnames(ak)));
    tags = fieldnames(ak);
    p = zeros(length(tags), length(k_id.(tags{1}))); % power spectrum density
    w = zeros(length(tags), length(k_id.(tags{1}))); % frequency in hertz
    for j = 1:length(tags)
        tag = tags{j};
        ak_j = ak.(tag);
        a_j = a.(tag);
        k_j = k_id.(tag);
        phi_j = phi.(tag);
        u_j = u(:, j);
        for k =1:length(k_j)
            u_j = u_j + ak_j(k)*sin((2*pi*k_j(k)*time)/t + phi_j(k));
            p(j, k) = (ak_j(k)/a_j)^2;
            w(j, k) = k_j(k)/t;
        end
        
        % plotting inputs
        u(:, j) = u_j;
        subplot(length(fieldnames(ak)), 1, j)
        plot(time, u_j)
        ylabel(tag)
        if j == length(tags)
            xlabel('time (s)')
        end        
    end
    
    % plotting PSD
    figure
    hold on
    bar_type = {'-', '--', '-.'};
    type_index = randi([1, 3], 1, height(p)); % random integers from 1 to 3
    for i = 1:height(p)
       type = bar_type{type_index(i)};
       bar(w(i, :), p(i, :),'BarWidth', 0.1)
       ylabel('power spectral density')
       xlabel('frequency (Hz)')
    end
    legend(tags)
    grid on
    hold off
end

function rpf_value = rpf(phi, ak_j, k_j, t)
    N = 3000;
    time = (0:t/N:t)';
    u_vals = zeros(length(time), 1);
    for i = 1:length(time)
        u_vals(i) = sum(ak_j.*sin(2*pi*k_j*time(i)/t + phi));
    end
    
    % RPF
    max_u = max(u_vals);
    min_u = min(u_vals);
    rms_u = sqrt(mean(u_vals.^2));
    pf = (max_u - min_u) / (2 * rms_u);
    rpf_value = pf/sqrt(2);
end

function [k_id, ak] = k_and_ak_calc(a, power_spec, m, tags, n_inputs, bins_per_input) 
    for i=1:length(tags)
        tag = tags{i};
        k_all = 1:1:m-1;
        ak.(tag) = zeros(bins_per_input, 1);
        if strcmp(string(power_spec.(tag)), 'uniform')
            ak.(tag)(:, 1) = a.(tag)/sqrt(bins_per_input);
            k_id.(tag)(:, 1) = k_all(i:n_inputs:end)+1;
        else
            ak.(tag)(:, 1) = a.(tag)*power_spec.(tag).^.5;
            k_id.(tag)(:, 1) = k_all(i:n_inputs:end)+1;
        end
    end
end

function u_tau = time_offset_zeros(tau, ak, k, phi, t)
    N = 3000;
    time = (0:t/N:t)';
    u = zeros(length(time), 1);
    for i = 1:length(ak)
        u = u + ak(i)*sin((2*pi*k(i)*time)/t + phi(i));
    end
    
    % Linear interpolation to find input given tau 
    [~, lower_index] = min(abs(time - tau));
    upper_index = lower_index + 1;
    alpha = (tau - time(lower_index)) / (time(upper_index) - time(lower_index));
    u_tau = abs((1 - alpha) * u(lower_index) + alpha * u(upper_index));
end

function inverseFunction = getPolynomialInverse(coefficients)
    % getPolynomialInverse: Computes the inverse of a polynomial symbolically
    % and returns it as a callable function handle.
    %
    % Input:
    %   coefficients - A vector of polynomial coefficients (highest degree first)
    %
    % Output:
    %   inverseFunction - A function handle to compute the inverse (degree to PWM)
    
    % Check if the Symbolic Math Toolbox is available
    if ~license('test', 'symbolic_toolbox')
        error('Symbolic Math Toolbox is required for this function.');
    end
    
    % Create symbolic variables
    syms pwm degree
    
    % Define the polynomial
    polynomial = 0;
    degreeOrder = length(coefficients) - 1;
    for i = 1:length(coefficients)
        polynomial = polynomial + coefficients(i) * pwm^(degreeOrder - (i - 1));
    end
    
    % Solve for pwm in terms of degree
    solutions = solve(polynomial == degree, pwm);
    
    % Choose the real-valued solution (if multiple solutions exist)
    % Wrap it in a function handle
    inverseFunction = matlabFunction(solutions, 'Vars', degree);
end
