clear all
close all

pwm_elv_fit = [0.0445 -65.185]; % polyfit between pwm(x) and elevator-deg (y)
pwm_ail_fit = [0.0628 -94.205];
pwm_rdr_fit = [0.0653 -98.142];

amplitude_deg = 6;  % Amplitude of the doublet in degrees
hold_time = 0.5;     % Time (in seconds) each pulse is held
sample_rate = 10;  % Sampling rate (samples per second)


%% END OF INPUT----------------------------------------------------------
% Generate and plot the doublet signal
[time, doublet] = generate_doublet(amplitude_deg, hold_time, sample_rate);
doublet = doublet';
% function to convert degree to pwm
deg2pwm_elv = getPolynomialInverse(pwm_elv_fit); 
deg2pwm_ail = getPolynomialInverse(pwm_ail_fit); 
deg2pwm_rdr = getPolynomialInverse(pwm_rdr_fit); 

elv = round(deg2pwm_elv(doublet)); % converting to pwm from polynomial relation
ail = round(deg2pwm_ail(doublet));
rdr = round(deg2pwm_rdr(doublet));
u_pwm = [elv ail rdr];
u_pwm = u_pwm - u_pwm(1, :); % subtract initial pwm so everything is a delta
time = round(time*1000); % converting time to ms due to Lua script constraints

% Writing doublet to excel
%file name
integer_part = floor(hold_time); % Get the integer part
decimal_part = abs(hold_time - integer_part); % Get the decimal part
hold_time_str = sprintf('%d_%d', integer_part, round(decimal_part * 10)); % Scale decimal part for clarity
file_name = sprintf(['doublet_%d_deg_' hold_time_str 's_hold.csv'], amplitude_deg);

input = [time' u_pwm ];
T = array2table(input);
T.Properties.VariableNames = {'Time' 'Elev_PWM' 'Ail_PWM' 'Rud_PWM'};
writetable(T, file_name)

function [time_vector, doublet_signal] = generate_doublet(amplitude_deg, hold_time, sample_rate)
    % Generates a doublet signal with the given amplitude (in degrees),
    % hold time, and sample rate. The signal starts and ends with zero
    % amplitude segments, each lasting the same duration as hold_time.
    %
    % Parameters:
    %   amplitude_deg : Amplitude of the doublet signal in degrees
    %   hold_time     : Time (in seconds) each pulse is held
    %   sample_rate   : Sampling rate (samples per second)
    %
    % Returns:
    %   time_vector    : The time vector corresponding to the signal
    %   doublet_signal : The generated doublet signal as a vector
    
    % Calculate the number of samples for hold time
    hold_samples = round(hold_time * sample_rate);
    
    % Compute total samples: 2 * hold_samples for start and end zeros,
    % and 2 * hold_samples for the doublet pulses (positive and negative)
    total_samples = 4 * hold_samples;
    
    % Create the time vector
    time_vector = (0:total_samples - 1) / sample_rate;
    
    % Initialize the signal with zeros
    doublet_signal = zeros(1, total_samples);
    
    % Define indices for the signal segments
    start_zero_end = hold_samples;
    pulse_start = start_zero_end + 1;
    pulse_end = pulse_start + hold_samples - 1;
    neg_pulse_start = pulse_end + 1;
    neg_pulse_end = neg_pulse_start + hold_samples - 1;
    end_zero_start = neg_pulse_end + 1;
    end_zero_end = total_samples; % Same as total_samples here
    
    % Add the positive pulse
    doublet_signal(pulse_start:pulse_end) = amplitude_deg;
    
    % Add the negative pulse
    doublet_signal(neg_pulse_start:neg_pulse_end) = -amplitude_deg;
    
    % Plot the signal
    figure;
    plot(time_vector, doublet_signal, 'LineWidth', 1.5);
    grid on;
    xlabel('Time (s)');
    ylabel('Amplitude (degrees)');
    title('Doublet Signal');
    xlim([0 time_vector(end)]);
end


function inverseFunction = getPolynomialInverse(coefficients)
    % getPolynomialInverse: Computes the inverse of a polynomial symbolically
    % and returns it as a callable function handle.
    %
    % Input:
    %   coefficients - A vector of polynomial coefficients (highest degree first)
    %
    % Output:
    %   inverseFunction - A function handle to compute the inverse (degree to PWM)
    
    % Check if the Symbolic Math Toolbox is available
    if ~license('test', 'symbolic_toolbox')
        error('Symbolic Math Toolbox is required for this function.');
    end
    
    % Create symbolic variables
    syms pwm degree
    
    % Define the polynomial
    polynomial = 0;
    degreeOrder = length(coefficients) - 1;
    for i = 1:length(coefficients)
        polynomial = polynomial + coefficients(i) * pwm^(degreeOrder - (i - 1));
    end
    
    % Solve for pwm in terms of degree
    solutions = solve(polynomial == degree, pwm);
    
    % Choose the real-valued solution (if multiple solutions exist)
    % Wrap it in a function handle
    inverseFunction = matlabFunction(solutions, 'Vars', degree);
end
