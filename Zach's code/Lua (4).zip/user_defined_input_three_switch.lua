local time_loop = 13 -- Time in ms of the loop
local ail_channel = 1-1 -- Aileron PWM signal channel
local elv_channel = 2-1 -- Elevator PWM signal channel
local rdr_channel = 4-1 -- Rudder PWM signal channel

local MULTISINE_CHANNEL=9 -- Channel of switch to start multisine
local TYPE_CHANNEL=10 -- Channel of three position switch to change maneuver type 

local start_deflection = false  -- Flag to start deflection after the distance is reached
local time_at_distance = nil
local stop_interp = false

local long_csv_data = {}  -- Table to store preloaded CSV data for longitudinal maneuver
local lat_csv_data = {}  -- Table to store preloaded CSV data for lateral-direction maneuver
local doublet_csv_data = {}  -- Table to store preloaded CSV data for doublet maneuver
local csv_loaded_long = false
local csv_loaded_lat = false
local csv_loaded_doublet = false

local current_index = 1  -- Track which data point we're using
local switch_flag = false

local doublet_id = 1

-- Function to preload the longitudinal CSV file incrementally
function preload_long()
  local file_long = io.open('/APM/scripts/long_data.csv', 'r')
  if not file_long then
    gcs:send_text(6, "Error: Unable to open CSV file.")
    return
  end
  file_long:read()  -- Skip the header

  local lines_loaded = 0

  -- Read a chunk of lines (e.g., 20 lines at a time) in each cycle
  for i = 1, 20 do
    local line = file_long:read()
    if line then
      local time_str, pwm_elv_str = line:match("([^,]+),([^,]+)")
      local time = tonumber(time_str:match("^%s*(.-)%s*$"))  -- Trim and convert to number
      local pwm_elv = tonumber(pwm_elv_str:match("^%s*(.-)%s*$"))    -- Trim and convert to number

      if time and pwm_elv then
        table.insert(long_csv_data, {time = time, pwm_elv = pwm_elv})
        lines_loaded = lines_loaded + 1
      end
    else
      -- Close the file when done
      file_long:close()
      file_long = nil
      csv_loaded_long = true  -- Mark the CSV as fully loaded
      gcs:send_text(6, "Longitudinal file fully loaded into memory.")
      break
    end
  end

  -- Debug: print how many lines were loaded in this cycle
  gcs:send_text(6, string.format("Loaded %d lines this cycle.", lines_loaded))
end

-- Function to preload the longitudinal CSV file incrementally
function preload_lat()
  local file_lat = io.open('/APM/scripts/lat_data.csv', 'r')
  if not file_lat then
    gcs:send_text(6, "Error: Unable to open CSV file.")
    return
  end
  file_lat:read()  -- Skip the header

  local lines_loaded = 0

  -- Read a chunk of lines (e.g., 20 lines at a time) in each cycle
  for i = 1, 20 do
    local line = file_lat:read()
    if line then
      local time_str, pwm_ail_str, pwm_rdr_str = line:match("([^,]+),([^,]+),([^,]+)")
      local time = tonumber(time_str:match("^%s*(.-)%s*$"))  -- Trim and convert to number
      local pwm_ail = tonumber(pwm_ail_str:match("^%s*(.-)%s*$"))    -- Trim and convert to number
      local pwm_rdr = tonumber(pwm_rdr_str:match("^%s*(.-)%s*$"))    -- Trim and convert to number

      if time and pwm_ail and pwm_rdr then
        table.insert(lat_csv_data, {time = time, pwm_ail=pwm_ail, pwm_rdr=pwm_rdr})
        lines_loaded = lines_loaded + 1
      end
    else
      -- Close the file when done
      file_lat:close()
      file_lat = nil
      csv_loaded_lat = true  -- Mark the CSV as fully loaded
      gcs:send_text(6, "Lateral file fully loaded into memory.")
      break
    end
  end

  -- Debug: print how many lines were loaded in this cycle
  gcs:send_text(6, string.format("Loaded %d lines this cycle.", lines_loaded))
end

function preload_doublet()
  local file_doublet = io.open('/APM/scripts/doublet.csv', 'r')
  if not file_doublet then
    gcs:send_text(6, "Error: Unable to open CSV file.")
    return
  end
  file_doublet:read()  -- Skip the header

  local lines_loaded = 0

  -- Read a chunk of lines (e.g., 20 lines at a time) in each cycle
  for i = 1, 20 do
    local line = file_doublet:read()
    if line then
      local time_str, pwm_elv_str, pwm_ail_str, pwm_rdr_str = line:match("([^,]+),([^,]+),([^,]+),([^,]+)")
      local time = tonumber(time_str:match("^%s*(.-)%s*$"))  -- Trim and convert to number
      local pwm_elv = tonumber(pwm_elv_str:match("^%s*(.-)%s*$"))
      local pwm_ail = tonumber(pwm_ail_str:match("^%s*(.-)%s*$"))
      local pwm_rdr = tonumber(pwm_rdr_str:match("^%s*(.-)%s*$"))

      if time and pwm_elv and pwm_ail and pwm_rdr then
        table.insert(doublet_csv_data, {time = time, pwm_elv=pwm_elv, pwm_ail=pwm_ail, pwm_rdr=pwm_rdr})
        lines_loaded = lines_loaded + 1
      end
    else
      -- Close the file when done
      file_doublet:close()
      file_doublet = nil
      csv_loaded_doublet = true  -- Mark the CSV as fully loaded
      gcs:send_text(6, "Lateral file fully loaded into memory.")
      break
    end
  end

  -- Debug: print how many lines were loaded in this cycle
  gcs:send_text(6, string.format("Loaded %d lines this cycle.", lines_loaded))
end
-- Function to find the nearest time points for interpolation
function find_nearest_long(elapsed_time)
  -- Iterate through the preloaded csv_data to find the appropriate time range
  for i = current_index, #long_csv_data - 1 do
    if long_csv_data[i].time <= elapsed_time and long_csv_data[i + 1].time > elapsed_time then
      current_index = i  -- Update current_index to start from this point next time
      return long_csv_data[i], long_csv_data[i + 1]  -- Return the two nearest points
    end
  end

  return nil, nil  -- No valid time range found (end of data)
end

function find_nearest_lat(elapsed_time)
  -- Iterate through the preloaded csv_data to find the appropriate time range
  for i = current_index, #lat_csv_data - 1 do
    if lat_csv_data[i].time <= elapsed_time and lat_csv_data[i + 1].time > elapsed_time then
      current_index = i  -- Update current_index to start from this point next time
      return lat_csv_data[i], lat_csv_data[i + 1]  -- Return the two nearest points
    end
  end

  return nil, nil  -- No valid time range found (end of data)
end

function find_nearest_doublet(elapsed_time)
  -- Iterate through the preloaded csv_data to find the appropriate time range
  for i = current_index, #doublet_csv_data - 1 do
    if doublet_csv_data[i].time <= elapsed_time and doublet_csv_data[i + 1].time > elapsed_time then
      current_index = i  -- Update current_index to start from this point next time
      return doublet_csv_data[i], doublet_csv_data[i + 1]  -- Return the two nearest points
    end
  end

  return nil, nil  -- No valid time range found (end of data)
end

-- Linear interpolation function
function interpolate(x1, y1, x2, y2, x)
  return y1 + (y2 - y1) * (x - x1) / (x2 - x1)
end

function update()
  -- Start deflection when vehicle reaches the target distance
  if arming:is_armed() and rc:get_pwm(MULTISINE_CHANNEL) > 1500 and not switch_flag then
    time_at_distance = millis():tofloat()
    initial_elv = SRV_Channels:get_output_pwm(19)  -- Get initial PWM values
    initial_ail = SRV_Channels:get_output_pwm(4)
    initial_rdr = SRV_Channels:get_output_pwm(21)
    start_deflection = true
    switch_flag = true
  elseif rc:get_pwm(MULTISINE_CHANNEL) < 1500 then
    start_deflection = false
    switch_flag = false
    stop_interp = false
    current_index = 1  -- Reset index
    time_at_distance = nil
    doublet_id = doublet_id + 1
    if doublet_id == 4 then
      doublet_id = 1
    end
  end

  -- Preload CSVs if not already loaded
  if not csv_loaded_long then
    preload_long()
    return update, time_loop
  end
  if not csv_loaded_lat then
    preload_lat()
    return update, time_loop
  end
  if not csv_loaded_doublet then
    preload_doublet()
    return update, time_loop
  end

  -- Interpolation logic
  if start_deflection and not stop_interp then
    local local_time = millis():tofloat()
    local elapsed_time = local_time - time_at_distance

    -- Longitudinal maneuver
    if rc:get_pwm(TYPE_CHANNEL) < 1800 then
      local point1, point2 = find_nearest_long(elapsed_time)
      if point1 and point2 then
        local interpolated_elv = interpolate(point1.time, point1.pwm_elv, point2.time, point2.pwm_elv, elapsed_time)
        local final_elv = math.floor(initial_elv + interpolated_elv)
        SRV_Channels:set_output_pwm_chan_timeout(elv_channel, final_elv, time_loop + 1)
      else
        gcs:send_text(6, "End of longitudinal CSV data.")
        stop_interp = true
      end

    -- Lateral-direction maneuver
    elseif rc:get_pwm(TYPE_CHANNEL) < 1800 and rc:get_pwm(TYPE_CHANNEL) > 1200 then
      local point1, point2 = find_nearest_lat(elapsed_time)
      if point1 and point2 then
        local interpolated_ail = interpolate(point1.time, point1.pwm_ail, point2.time, point2.pwm_ail, elapsed_time)
        local interpolated_rdr = interpolate(point1.time, point1.pwm_rdr, point2.time, point2.pwm_rdr, elapsed_time)
        local final_ail = math.floor(initial_ail + interpolated_ail)
        local final_rdr = math.floor(initial_rdr + interpolated_rdr)
        SRV_Channels:set_output_pwm_chan_timeout(ail_channel, final_ail, time_loop + 1)
        SRV_Channels:set_output_pwm_chan_timeout(rdr_channel, final_rdr, time_loop + 1)
      else
        gcs:send_text(6, "End of lateral-direction CSV data.")
        stop_interp = true
      end

    elseif rc:get_pwm(TYPE_CHANNEL) < 1200 then
      -- Doublet maneuver
      local point1, point2 = find_nearest_doublet(elapsed_time)
      if point1 and point2 then
        if doublet_id == 1 then
          local interpolated_elv = interpolate(point1.time, point1.pwm_elv, point2.time, point2.pwm_elv, elapsed_time)
          local final_elv = math.floor(initial_elv + interpolated_elv)
          SRV_Channels:set_output_pwm_chan_timeout(elv_channel, final_elv, time_loop + 1)
        elseif doublet_id == 2 then
          local interpolated_ail = interpolate(point1.time, point1.pwm_ail, point2.time, point2.pwm_ail, elapsed_time)
          local final_ail = math.floor(initial_ail + interpolated_ail)
          SRV_Channels:set_output_pwm_chan_timeout(ail_channel, final_ail, time_loop + 1)
        elseif doublet_id == 3 then
          local interpolated_rdr = interpolate(point1.time, point1.pwm_rdr, point2.time, point2.pwm_rdr, elapsed_time)
          local final_rdr = math.floor(initial_rdr + interpolated_rdr)
          SRV_Channels:set_output_pwm_chan_timeout(rdr_channel, final_rdr, time_loop + 1)
        end
      else
        gcs:send_text(6, "End of doublet CSV data.")
        stop_interp = true
      end
    end
  end

  -- Stop the script when interpolation is complete
  if stop_interp then
    gcs:send_text(6, "Script execution completed.")
    return nil, 0
  end

  return update, time_loop 

-- Start the script
return update, 5000 --initial call of update function after 5s of startup 
